package com.example.kaelen.lab_9;

/**
 * Created by Kaelen on 5/6/2018.
 */

public class BucketList {
    private String id;
    private String name;

    public BucketList(){

    }

    public BucketList(String newid, String newName){
        id = newid;
        name = newName;
    }

    public String getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public String toString(){
        return this.name;
    }
}

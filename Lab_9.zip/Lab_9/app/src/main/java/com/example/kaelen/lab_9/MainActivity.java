package com.example.kaelen.lab_9;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference();
    DatabaseReference itemref = database.getReference("items");

    List items = new ArrayList<>();
    ArrayAdapter<BucketList> listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LinearLayout layout = new LinearLayout(MainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText nameEditText = new EditText(MainActivity.this);
                nameEditText.setHint("Bucket list item");
                layout.addView(nameEditText);

                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Add a New Bucket List Item");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        String itemName = nameEditText.getText().toString();
                        if(itemName.trim().length()>0){
                            String key = itemref.push().getKey();
                            BucketList newItem = new BucketList(key,itemName);
                            itemref.child(key).child("name").setValue(newItem.getName());
                        }
                    }
                });
                dialog.setNegativeButton("Cancel",null);
                dialog.show();
            }
        });

        ListView bucketList = (ListView) findViewById(R.id.listView);
        listAdapter = new ArrayAdapter<BucketList>(this,android.R.layout.simple_list_item_1,items);
        bucketList.setAdapter(listAdapter);

        ValueEventListener firebaseListener = new ValueEventListener(){
            @Override
            public void onDataChange(DataSnapshot dataSnapshot){
                items.clear();
                for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                    String newId = snapshot.getKey();
                    BucketList bucketItem = snapshot.getValue(BucketList.class);
                    BucketList newItem = new BucketList(newId,bucketItem.getName());
                    items.add(newItem);
                }
                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error){
                Log.w("oncreate","Failed to read value.",error.toException());
            }
        };

        itemref.addValueEventListener(firebaseListener);
        registerForContextMenu(bucketList);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view,ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu,view,menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String itemname = ((TextView)adapterContextMenuInfo.targetView).getText().toString();
        menu.setHeaderTitle("Delete "+itemname);
        menu.add(1,1,1,"yes");
        menu.add(2,2,2,"no");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if(itemId == 1){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            BucketList selectedItem = (BucketList)items.get(info.position);
            String itemid = selectedItem.getId();
            itemref.child(itemid).removeValue();
        }
        return true;
    }
}

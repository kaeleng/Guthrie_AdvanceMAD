//
//  Images.swift
//  Lab5
//
//  Created by Kaelen Guthrie on 3/18/18.
//  Copyright © 2018 Kaelen Guthrie. All rights reserved.
//

import Foundation
import RealmSwift

class Images: Object{
    @objc dynamic var imageName = ""
    @objc dynamic var imagePath = ""
}

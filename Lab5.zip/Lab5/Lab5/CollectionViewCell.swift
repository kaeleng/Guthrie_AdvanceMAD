//
//  CollectionViewCell.swift
//  
//
//  Created by Kaelen Guthrie on 3/18/18.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}

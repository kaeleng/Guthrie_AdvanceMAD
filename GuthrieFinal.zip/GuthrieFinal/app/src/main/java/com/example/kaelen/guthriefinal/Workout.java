package com.example.kaelen.guthriefinal;

/**
 * Created by Kaelen on 5/6/2018.
 */

public class Workout {
    private String category;
    //private ArrayList<String> workouts = new ArrayList<>();

    public Workout(String workoutCategory){
        this.category = workoutCategory;
    }

    public static final Workout[] Cardio = {
            new Workout("Running")
    };

    public static final Workout[] Strength = {
            new Workout("Pushupss")
        };

    public static final Workout[] Flexibility = {
            new Workout("Stretch")
        };


    /*public static final Workout[] listWorkouts = {
            new Workout("Cardio",new ArrayList<String>(Arrays.asList("Running", "Swimming"))),
            new Workout("Strength", new ArrayList<String>(Arrays.asList("Squats","Pushups"))),
            new Workout("Flexibility", new ArrayList<String>(Arrays.asList("Stretch")))
    };*/

    public String getCategory(){
        return category;
    }

    /*public ArrayList<String> getWorkouts(){
        return workouts;
    }*/

    public String toString(){
        return this.category;
    }

}

package com.example.kaelen.guthriefinal;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class WorkoutList extends AppCompatActivity {

    private String workouttype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_list);

        final ListView workoutList = (ListView)findViewById(R.id.listView2);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        workouttype = intent.getStringExtra("workouttype");

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(WorkoutList.this);
                final EditText edittext = new EditText(WorkoutList.this);
                dialog.setView(edittext);
                dialog.setMessage("Add Workout");

                dialog.setPositiveButton("Add",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){
                        String activityName = edittext.getText().toString();
                        if(!activityName.isEmpty()){
                            /*switch(workouttype){
                                case "Cardio":
                                    Workout.Cardio.
                            }*/


                        }
                    }
                });
            }
        });



        ArrayAdapter<Workout> listAdapter;

        switch(workouttype){
            case "Cardio":
                listAdapter = new ArrayAdapter<Workout>(this,android.R.layout.simple_list_item_1, Workout.Cardio);
                break;
            case "Strength":
                listAdapter = new ArrayAdapter<Workout>(this,android.R.layout.simple_list_item_1, Workout.Strength);
                break;
            case "Flexibility":
                listAdapter = new ArrayAdapter<Workout>(this,android.R.layout.simple_list_item_1, Workout.Flexibility);
                break;
            default:
                listAdapter = new ArrayAdapter<Workout>(this,android.R.layout.simple_list_item_1, Workout.Cardio);
                break;
        }

        workoutList.setAdapter(listAdapter);

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.event_signup:
                Intent intent = new Intent(this, SignupActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}

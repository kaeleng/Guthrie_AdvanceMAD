package com.example.kaelen.lab_7;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Kaelen on 4/10/2018.
 */

public class School {
    private String department;
    private ArrayList<String> classes = new ArrayList<>();

    //constructor
    private School(String classDepartment, ArrayList<String> userClasses){
        this.department = classDepartment;
        this.classes = new ArrayList<String>(userClasses);
    }

    public static final School[] schoolStuff={
            new School("ATLS", new ArrayList<String>(Arrays.asList("Web","Image","Text","Form","Object","Sound"))),
            new School("CSCI", new ArrayList<String>(Arrays.asList("Data Structures","Discrete Structures","Computer Systems"))),
            new School("APPM", new ArrayList<String>(Arrays.asList("Calc 1", "Calc 2", "calc 3")))
    };

    public String getDepartment(){
        return department;
    }

    public ArrayList<String> getClasses(){
        return classes;
    }

    public String toString(){
        return this.department;
    }

}

package com.example.kaelen.lab_7;


import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class ClassNameFragment extends Fragment implements View.OnClickListener {

    private ArrayAdapter<String> adapter;

    private long classId;


    public ClassNameFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        if(savedInstanceState != null){
            classId = savedInstanceState.getLong("classId");
        }

        return inflater.inflate(R.layout.fragment_class_name, container, false);


    }

    @Override
    public void onStart(){
        super.onStart();
        View view = getView();
        ListView listClasses = (ListView) view.findViewById(R.id.classlistView);

        ArrayList<String> classlist = new ArrayList<String>();
        classlist = School.schoolStuff[(int)classId].getClasses();

        adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,classlist);
        listClasses.setAdapter(adapter);

        Button addClassButton = (Button) view.findViewById(R.id.addClassButton);
        addClassButton.setOnClickListener(this);

        registerForContextMenu(listClasses);
    }

    public void setClassId(long id){
        this.classId=id;
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putLong("classId", classId);
    }

    interface ButtonClickListener{
        void addclassclicked(View view);
    }

    private ButtonClickListener listener;

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        listener = (ButtonClickListener)context;
    }

    @Override
    public void onClick(View view){
        if (listener !=null){
            listener.addclassclicked(view);
        }
    }

    public void addClass(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());

        final EditText edittext = new EditText(getActivity());

        dialog.setView(edittext);
        dialog.setTitle("Add Class");

        dialog.setPositiveButton("Add", new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichButton){
                String className = edittext.getText().toString();
                if(!className.isEmpty()){
                    School.schoolStuff[(int)classId].getClasses().add(className);
                    ClassNameFragment.this.adapter.notifyDataSetChanged();
                }
            }
        });

        dialog.setNegativeButton("Cancel",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialog, int whichButton){}
        });
        dialog.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu, view, menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String classname = adapter.getItem(adapterContextMenuInfo.position);
        menu.setHeaderTitle("Delete" + classname);
        menu.add(1,1,1,"Yes");
        menu.add(2,2,2,"No");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if(itemId == 1){
            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            School.schoolStuff[(int)classId].getClasses().remove(info.position);
            ClassNameFragment.this.adapter.notifyDataSetChanged();
        }
        return true;
    }
}


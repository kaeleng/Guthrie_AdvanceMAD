package com.example.kaelen.lab_7;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity implements DepartmentListFragment.DepartmentListListener, ClassNameFragment.ButtonClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void itemClicked(long id) {


        View fragmentContainer = findViewById(R.id.detail_frag);
        if(fragmentContainer != null){
            ClassNameFragment frag = new ClassNameFragment();
            frag.setClassId(id);
            FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.replace(R.id.detail_frag,frag);
            ft.addToBackStack(null);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
            ft.commit();
        }else{
            Intent intent = new Intent(this, DetailActivity.class);
            intent.putExtra("id",(int)id);
            startActivity(intent);
        }
    }

    @Override
    public void onBackPressed(){
        if(getFragmentManager().getBackStackEntryCount()>0){
            getFragmentManager().popBackStack();;
        }else{
            super.onBackPressed();
        }
    }

    @Override
    public void addclassclicked(View view) {
        ClassNameFragment fragment = (ClassNameFragment)getFragmentManager().findFragmentById(R.id.detail_frag);
        fragment.addClass();
    }
}

package com.example.kaelen.lab_7;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class DetailActivity extends Activity implements ClassNameFragment.ButtonClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ClassNameFragment classNameFragment = (ClassNameFragment) getFragmentManager().findFragmentById(R.id.detail_frag);
        int classId = (int) getIntent().getExtras().get("id");
        classNameFragment.setClassId(classId);
    }

    @Override
    public void addclassclicked(View view) {
        ClassNameFragment fragment = (ClassNameFragment)getFragmentManager().findFragmentById(R.id.detail_frag);
        fragment.addClass();
    }
}

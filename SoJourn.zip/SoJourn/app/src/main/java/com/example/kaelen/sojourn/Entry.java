package com.example.kaelen.sojourn;

/**
 * Created by Kaelen on 5/1/2018.
 */

public class Entry {
    private String entryTitle, entryText, entryImage;

    public Entry(){

    }

    public Entry(String entryTitle, String entryText, String entryImage){
        this.entryTitle = entryTitle;
        this.entryText = entryText;
        this.entryImage = entryImage;
    }

    public String getEntryTitle(){
        return entryTitle;
    }

    public String getEntryText() {
        return entryText;
    }

    public String getEntryImage(){
        return entryImage;
    }

    public void setEntryTitle(){
        this.entryTitle = entryTitle;
    }

    public void setEntryText(){
        this.entryText = entryText;
    }

    public void setEntryImage(){
        this.entryImage = entryImage;
    }
}

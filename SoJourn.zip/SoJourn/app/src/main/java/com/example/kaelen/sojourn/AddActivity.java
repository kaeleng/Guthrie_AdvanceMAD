package com.example.kaelen.sojourn;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class AddActivity extends AppCompatActivity {

    private Uri uri = null;
    private ImageButton imageButton;
    private EditText editName;
    private EditText editMem;
    private StorageReference storageReference;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    ImageView targetImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        editName = (EditText)findViewById(R.id.editName);
        editMem = (EditText)findViewById(R.id.editMemory);
        targetImage = (ImageView)findViewById(R.id.targetimage);

        storageReference = FirebaseStorage.getInstance().getReference();
        databaseReference = database.getInstance().getReference().child("SoJourn");
    }

    public void imageButtonClicked(View view){
        /*Intent intent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("Image*//*");*/
        /*Intent galleryintent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryintent.setType("Image*//*");
        startActivityForResult(galleryintent,GALLERY_REQUEST);*/
        Intent intent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode == RESULT_OK){
            /*uri = data.getData();
            imageButton = (ImageButton) findViewById(R.id.imageButton);
            imageButton.setImageURI(uri);*/
            uri = data.getData();
            targetImage.setImageURI(uri);
            /*Uri targetUri = data.getData();
            //textTargetUri.setText(targetUri.toString());
            Bitmap bitmap;
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(targetUri));
                targetImage.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }*/

        }
    }

    public void submitButtonClicked(View view) {
        final String titleValue = editName.getText().toString().trim();
        final String titleMem = editMem.getText().toString().trim();

        if(!TextUtils.isEmpty(titleValue) && !TextUtils.isEmpty(titleMem)){
            StorageReference filePath = storageReference.child("PostImage").child(uri.getLastPathSegment());
            filePath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Uri downloadurl = taskSnapshot.getDownloadUrl();
                    //Toast.makeText(AddActivity.this,"Upload Complete",Toast.LENGTH_LONG).show();
                    DatabaseReference newPost = databaseReference.push();
                    newPost.child("title").setValue(titleValue);
                    newPost.child("mem").setValue(titleMem);
                    newPost.child("image").setValue(downloadurl.toString());
                    /*newPost.child("entries").child("entryTitle").setValue("This will be the tile of an entry");
                    newPost.child("entries").child("entryText").setValue("Here is where the memory will go");*/

                }
            });
        }
        Intent intent = new Intent(AddActivity.this,MainActivity.class);
        startActivity(intent);
    }
}

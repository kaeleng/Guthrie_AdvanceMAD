package com.example.kaelen.sojourn;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class TripDetailActivity extends AppCompatActivity {

    private RecyclerView mEntryList;
    private DatabaseReference mDatabase;
    private String post_key = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);

        post_key = getIntent().getExtras().getString("tripId");

        mEntryList = (RecyclerView) findViewById(R.id.detail_list);
        mEntryList.setHasFixedSize(true);
        mEntryList.setLayoutManager(new LinearLayoutManager(this));
        mDatabase = FirebaseDatabase.getInstance().getReference().child("SoJourn").child(post_key).child("entries");


        //Log.i("post key", "Post key: " + post_key);
    }

    @Override
    protected void onStart() {
        super.onStart();



        FirebaseRecyclerAdapter<Entry,EntryViewHolder> FBRA = new FirebaseRecyclerAdapter<Entry, EntryViewHolder>(
                Entry.class,
                R.layout.memory_row,
                EntryViewHolder.class,
                mDatabase
        ) {
            @Override
            protected void populateViewHolder(EntryViewHolder viewHolder, Entry model, int position) {

                //final String post_key = getRef(position).getKey().toString();

                viewHolder.setEntryTitle(model.getEntryTitle());
                viewHolder.setEntryText(model.getEntryText());
                viewHolder.setEntryImage(getApplicationContext(),model.getEntryImage());

            }
        };
        mEntryList.setAdapter(FBRA);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.detail_menu, menu);
        return true;
    }

    public static class EntryViewHolder extends RecyclerView.ViewHolder{
        View mView;
        public EntryViewHolder(View itemView){
            super(itemView);
            mView = itemView;
        }

        public void setEntryTitle(String title){
            TextView post_title = (TextView) mView.findViewById(R.id.textTitle);
            post_title.setText(title);
        }

        public void setEntryText(String mem){
            TextView post_mem = (TextView) mView.findViewById(R.id.textMem);
            post_mem.setText(mem);
        }
        public void setEntryImage(Context ctx, String image){
            ImageView post_image = (ImageView) mView.findViewById(R.id.post_image);
            Picasso.get().load(image).into(post_image);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.addIcon){
            Intent addIntent = new Intent(TripDetailActivity.this,AddDetailActivity.class);
            addIntent.putExtra("tripId",post_key);
            startActivity(addIntent);
        }

        return super.onOptionsItemSelected(item);
    }
}

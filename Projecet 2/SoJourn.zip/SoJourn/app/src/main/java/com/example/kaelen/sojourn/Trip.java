package com.example.kaelen.sojourn;

import java.util.ArrayList;

/**
 * Created by Kaelen on 4/30/2018.
 */

public class Trip {
    private String title,mem,image;
    //private ArrayList<Entry> entries = new ArrayList<>();
    private String entryTitle, entryText, entryImage;
    private ArrayList<String> entries = new ArrayList<>();

    public Trip(){
    }

    public Trip(String title, String mem, String image){
        this.title = title;
        this.mem = mem;
        this.image = image;
    }

    public Trip(String eTitle, String eText, String eImage,ArrayList<String> entryList){
        this.entryTitle = eTitle;
        this.entryText = eText;
        this.entryImage = eImage;
        this.entries = new ArrayList<String>(entryList);
    }

    public String getTitle(){
        return title;
    }

    public String getImage(){
        return image;
    }

    public String getMem(){
        return mem;
    }

    //public ArrayList<Entry> getEntries(){return entries;}

    public String getEntryTitle(){return entryTitle; }

    public String getEntryText() {return entryText; }

    public String getEntryImage(){return entryImage; }

    public void setEntryTitle(String entryTitle) {this.entryTitle = entryTitle;}

    public void setEntryText(String entryText){this.entryText = entryText;}

    public void setEntryImage(String entryImage){this.entryImage = entryImage;}

    public void setTitle(String title){
        this.title = title;
    }

    public void setImage(String image){
        this.image = image;
    }

    public void setMem(String mem){
        this.mem = mem;
    }
}

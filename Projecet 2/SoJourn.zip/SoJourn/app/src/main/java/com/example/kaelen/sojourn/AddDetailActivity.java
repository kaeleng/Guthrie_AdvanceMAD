package com.example.kaelen.sojourn;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class AddDetailActivity extends AppCompatActivity {

    private Uri uri = null;
    private ImageButton imageButton;
    private EditText editName;
    private EditText editMem;
    ImageView targetImage;
    private StorageReference storageReference;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private String post_key = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_detail);

        editName = (EditText)findViewById(R.id.editMemoryName);
        editMem = (EditText)findViewById(R.id.editMemoryDetail);
        targetImage = (ImageView)findViewById(R.id.targetimage);

        post_key = getIntent().getExtras().getString("tripId");

        storageReference = FirebaseStorage.getInstance().getReference();
        databaseReference = database.getInstance().getReference().child("SoJourn").child(post_key).child("entries");
    }

    public void imageButtonClicked(View view){
        Intent intent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode == RESULT_OK){
            /*uri = data.getData();
            imageButton = (ImageButton) findViewById(R.id.imageButton);
            imageButton.setImageURI(uri);*/
            uri = data.getData();
            targetImage.setImageURI(uri);
            /*Uri targetUri = data.getData();
            //textTargetUri.setText(targetUri.toString());
            Bitmap bitmap;
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(targetUri));
                targetImage.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }*/

        }
    }

    public void submitButtonClicked(View view){
        final String titleValue = editName.getText().toString().trim();
        final String titleMem = editMem.getText().toString().trim();

        if(!TextUtils.isEmpty(titleValue) && !TextUtils.isEmpty(titleMem)){
            StorageReference filePath = storageReference.child("EntryImage").child(uri.getLastPathSegment());
            filePath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Uri downloadurl = taskSnapshot.getDownloadUrl();
                    //Toast.makeText(AddActivity.this,"Upload Complete",Toast.LENGTH_LONG).show();
                    DatabaseReference newEntry = databaseReference.push();
                    /*newEntry.child("entryTitle").setValue(titleValue);
                    newEntry.child("entryText").setValue(titleMem);
                    newEntry.child("entryImage").setValue(downloadurl.toString());*/
                    newEntry.child("entryTitle").setValue(titleValue);
                    newEntry.child("entryText").setValue(titleMem);
                    newEntry.child("entryImage").setValue(downloadurl.toString());
                }
            });
        }

        Intent submitIntent = new Intent(AddDetailActivity.this,TripDetailActivity.class);
        submitIntent.putExtra("tripId",post_key);
        startActivity(submitIntent);
    }
}

package com.example.kaelen.lab_6;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class ClassListActivity extends ListActivity {

    private String classtype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       /* ActionBar actionBar = getActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.RED));*/
        Intent i = getIntent();
        classtype = i.getStringExtra("classtype");
        ListView listClasses = getListView();
        ArrayAdapter<ClassOptions> listAdapter;
        switch (classtype) {
            case "CSCI":
                listAdapter = new ArrayAdapter<ClassOptions>(this, android.R.layout.simple_list_item_1, ClassOptions.csci);
                break;
            case "ATLS":
                listAdapter = new ArrayAdapter<ClassOptions>(this, android.R.layout.simple_list_item_1, ClassOptions.atls);
                break;
            case "APPM":
                listAdapter = new ArrayAdapter<ClassOptions>(this, android.R.layout.simple_list_item_1, ClassOptions.appm);
                break;
            default:
                listAdapter = new ArrayAdapter<ClassOptions>(this, android.R.layout.simple_list_item_1, ClassOptions.csci);
                break;
        }
        listClasses.setAdapter(listAdapter);
    }

    @Override
    public void onListItemClick(ListView listVeiw, View view, int position, long id){
        Intent intent = new Intent(ClassListActivity.this, DescriptionActivity.class);
        intent.putExtra("classtype", (int) id);
        startActivity(intent);
    }


    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //String url = "https://mycuinfo.colorado.edu";
        switch(item.getItemId()){
            case R.id.open_browser:

               /* Uri uriURL = Uri.parse(url);
                Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriURL);
                startActivity(launchBrowser);*/
                Intent intent = new Intent(this,BrowserActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);


        }
    }

}

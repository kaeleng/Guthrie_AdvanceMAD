package com.example.kaelen.lab_6;

/**
 * Created by Kaelen on 4/3/2018.
 */

public class ClassOptions {
    private String name;

    private ClassOptions(String newname){
        this.name = newname;
    }

    public static final ClassOptions[] csci = {
            new ClassOptions("Data Structures"),
            new ClassOptions("Discrete Structures"),
            new ClassOptions("Computer Systems")
    };

    public static final ClassOptions[] atls = {
            new ClassOptions("Objects"),
            new ClassOptions("Form"),
            new ClassOptions("Web"),
            new ClassOptions("Image"),
            new ClassOptions("Text")
    };

    public static final ClassOptions[] appm = {
            new ClassOptions("Calculus 1"),
            new ClassOptions("Calculus 2"),
            new ClassOptions("Calculus 3"),
            new ClassOptions("Linear Algebra")
    };

    public String getName(){
        return name;
    }

    public String toString(){
        return this.name;
    }
}

package com.example.kaelen.lab_6;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> listView, View view, int position, long id){
                String classtype = (String) listView.getItemAtPosition(position);
                Intent intent = new Intent(MainActivity.this, ClassListActivity.class);
                intent.putExtra("classtype", classtype);
                startActivity(intent);
            }

        };
        ListView listview = (ListView) findViewById(R.id.ListView);
        listview.setOnItemClickListener(itemClickListener);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //String url = "https://mycuinfo.colorado.edu";
        switch(item.getItemId()){
            case R.id.open_browser:

               /* Uri uriURL = Uri.parse(url);
                Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriURL);
                startActivity(launchBrowser);*/
                Intent intent = new Intent(this,BrowserActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);


        }
    }
}
